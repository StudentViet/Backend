<?php echo e($slot); ?>

<?php /**PATH D:\Website\backend\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>