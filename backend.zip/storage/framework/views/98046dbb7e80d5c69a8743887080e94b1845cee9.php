<?php $__env->startComponent('mail::message'); ?>
# Chào <?php echo e($offer['name']); ?>


bên <?php echo e(config('app.name')); ?> bọn mình vừa nhận được yêu cầu lấy lại mật khẩu từ phía bạn phải không ? <br/>
<small><b>Nếu không phải do bạn thực hiện hãy bỏ qua email này nhé.</b></small>
<?php $__env->startComponent('mail::button', ['url' => $offer['url'], 'color' => 'success']); ?>
Lấy lại mật khẩu
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Website\backend\resources\views/emails/offerSendMail.blade.php ENDPATH**/ ?>