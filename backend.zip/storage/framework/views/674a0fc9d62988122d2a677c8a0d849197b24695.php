<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<img src="https://i.imgur.com/VsRCPQI.png" style="width:100%" class="logo" alt="StudentViet Logo">
</a>
</td>
</tr>
<?php /**PATH D:\Website\backend\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>