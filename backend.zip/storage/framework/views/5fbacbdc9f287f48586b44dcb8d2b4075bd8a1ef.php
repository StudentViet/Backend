[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\Website\backend\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>