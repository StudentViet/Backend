<?php

namespace App\Http\Controllers\Api\ClassRoom;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function getList()
    {
    }

    public function show($id)
    {
    }

    public function destroy($id)
    {
    }
}
